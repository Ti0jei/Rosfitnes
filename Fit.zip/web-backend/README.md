# web-backend
Express API с валидацией Telegram WebApp `initData`.

## Запуск
```bash
cd web-backend
cp .env.example .env   # впиши реальный BOT_TOKEN, CORS_ORIGIN
npm i
npm run dev            # или npm start
