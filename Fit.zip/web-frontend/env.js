window.ENV = {
  API_BASE: "https://ti0jei-rosfitnes-c178.twc1.net",
  TG_BOT_NAME: "@Fitdew_bot"
};
